/**
 * 
 */
/**
 * @author Seguridad
 *
 */
module ConversorDeDivisasYTemperatura {
}