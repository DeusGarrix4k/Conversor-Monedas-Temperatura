package conversorDeDivisasYTemperatura;

import java.util.Scanner;

public class Conversor {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Bienvenido al conversor de monedas y temperatura");

        System.out.println("¿Qué desea convertir?");
        System.out.println("1. Moneda");
        System.out.println("2. Temperatura");
        System.out.print("Ingrese el número correspondiente a su elección: ");

        int opcion = sc.nextInt();

        if (opcion == 1) {

            System.out.println("\nHa elegido convertir moneda\n");

            double tipoDeCambio;

            System.out.println("Seleccione el tipo de cambio:");
            System.out.println("1. Peso Mexicano a Dólar Estadounidense");
            System.out.println("2. Peso Mexicano a Euro");
            System.out.println("3. Peso Mexicano a Libra Esterlina");
            System.out.println("4. Peso Mexicano a Yen Japonés");
            System.out.println("5. Peso Mexicano a Dólar Canadiense");
            System.out.println("6. Peso Mexicano a Franco Suizo");
            System.out.println("7. Peso Mexicano a Dólar Australiano");
            System.out.println("8. Peso Mexicano a Yuan Chino");
            System.out.println("9. Peso Mexicano a Corona Sueca");
            System.out.println("10. Peso Mexicano a Real Brasileño");
            System.out.print("Ingrese el número correspondiente al tipo de cambio que desea utilizar: ");

            int tipoDeCambioElegido = sc.nextInt();

            switch (tipoDeCambioElegido) {
                case 1:
                    tipoDeCambio = 0.050;
                    break;
                case 2:
                    tipoDeCambio = 0.042;
                    break;
                case 3:
                    tipoDeCambio = 0.036;
                    break;
                case 4:
                    tipoDeCambio = 5.53;
                    break;
                case 5:
                    tipoDeCambio = 0.064;
                    break;
                case 6:
                    tipoDeCambio = 0.047;
                    break;
                case 7:
                    tipoDeCambio = 0.067;
                    break;
                case 8:
                    tipoDeCambio = 0.33;
                    break;
                case 9:
                    tipoDeCambio = 0.42;
                    break;
                case 10:
                    tipoDeCambio = 0.27;
                    break;
                default:
                    System.out.println("La opción ingresada no es válida.");
                    return;
            }

            double cantidadEnPesosMexicanos;

            System.out.print("Ingrese la cantidad en Pesos Mexicanos que desea convertir: ");
            cantidadEnPesosMexicanos = sc.nextDouble();

            double cantidadConvertida = cantidadEnPesosMexicanos * tipoDeCambio;

            System.out.println(cantidadEnPesosMexicanos + " Pesos Mexicanos equivalen a " + cantidadConvertida + " en la moneda elegida.");

        } else if (opcion == 2) {

            System.out.println("\nHa elegido convertir temperatura\n");

            double temperaturaEnCelsius;
            double temperaturaEnFarenheit;

            System.out.print("Ingrese la temperatura en grados Celsius que desea convertir: ");
            temperaturaEnCelsius = sc.nextDouble();

            temperaturaEnFarenheit = (temperaturaEnCelsius * 1.8) + 32;

            System.out.println(temperaturaEnCelsius + " grados Celsius equivalen a " + temperaturaEnFarenheit + " grados Farenheit.");

        } else {
            System.out.println("La opción ingresada no es válida.");
        }

        sc.close();
    }

}

